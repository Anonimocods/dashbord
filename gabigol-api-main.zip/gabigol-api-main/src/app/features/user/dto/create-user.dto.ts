export interface CreateUserDto {
  name: string;
  gender: string;
  cpf: string;
  cardNumber: string;
  age: string;
  status: string;
  dateOfBirth: Date;
}
